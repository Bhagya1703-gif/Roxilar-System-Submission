const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const pool = require('./db');
const bcrypt = require('bcrypt');
const { body, validationResult } = require('express-validator');

const app = express();
const PORT = 3000;
const SECRET = 'your_jwt_secret';
const SALT_ROUNDS = 10;

app.use(cors());
app.use(express.json());

// Authentication middleware
const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).send('Unauthorized');
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).send('Invalid token');
  }
};

// Role-based middleware
const isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') return res.status(403).send('Forbidden');
  next();
};

const isOwner = (req, res, next) => {
  if (req.user.role !== 'owner') return res.status(403).send('Forbidden');
  next();
};

const isUser = (req, res, next) => {
  if (req.user.role !== 'user') return res.status(403).send('Forbidden');
  next();
};

// Validation middleware
const validate = (validations) => {
  return async (req, res, next) => {
    await Promise.all(validations.map(validation => validation.run(req)));
    const errors = validationResult(req);
    if (errors.isEmpty()) {
      return next();
    }
    res.status(400).json({ errors: errors.array() });
  };
};

// Registration (only for non-admin users)
app.post('/register', 
  validate([
    body('name').notEmpty().trim(),
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 8 }),
    body('role').optional().isIn(['user', 'owner'])
  ]),
  async (req, res) => {
    const { name, email, address, password, role = 'user' } = req.body;
    
    try {
      const existingUser = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
      if (existingUser.rows.length > 0) {
        return res.status(400).json({ message: "User already exists" });
      }
      
      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      
      await pool.query(
        "INSERT INTO users (name, email, address, password, role) VALUES ($1, $2, $3, $4, $5)",
        [name, email, address, hashedPassword, role]
      );
      res.status(201).json({ message: "User registered successfully" });
    } catch (err) {
      console.error('Error during registration:', err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

require('dotenv').config();

if (!process.env.ADMIN_REGISTER_KEY) {
    console.error('FATAL: ADMIN_REGISTER_KEY missing from .env');
    process.exit(1);
  }

// In your server.js or auth routes file
app.post('/register-admin', 
    validate([
      body('name').notEmpty().trim(),
      body('email').isEmail().normalizeEmail(),
      body('password').isLength({ min: 8 }),
      body('admin_key').equals(process.env.ADMIN_REGISTER_KEY)
    ]),
    async (req, res) => {
      const { name, email, address, password } = req.body;
      
      try {
        // Check if admin already exists
        const adminCount = await pool.query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
        if (adminCount.rows[0].count > 0) {
          return res.status(403).json({ message: "Admin registration is closed" });
        }
  
        const existingUser = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
        if (existingUser.rows.length > 0) {
          return res.status(400).json({ message: "User already exists" });
        }
        
        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
        
        await pool.query(
          "INSERT INTO users (name, email, address, password, role) VALUES ($1, $2, $3, $4, 'admin')",
          [name, email, address, hashedPassword]
        );
        res.status(201).json({ message: "Admin registered successfully" });
      } catch (err) {
        console.error('Error during admin registration:', err);
        res.status(500).json({ message: "Server error" });
      }
    }
  );

  
// Login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(400).send('Invalid credentials');
    }
    
    const token = jwt.sign({ id: user.id, role: user.role }, SECRET, { expiresIn: '1h' });
    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).send('Login failed');
  }
});

// Admin Dashboard Stats
app.get('/admin/stats', authenticate, isAdmin, async (req, res) => {
  try {
    const [usersCount, storesCount, ratingsCount] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM users'),
      pool.query('SELECT COUNT(*) FROM stores'),
      pool.query('SELECT COUNT(*) FROM ratings')
    ]);
    
    res.json({
      totalUsers: parseInt(usersCount.rows[0].count),
      totalStores: parseInt(storesCount.rows[0].count),
      totalRatings: parseInt(ratingsCount.rows[0].count)
    });
  } catch (err) {
    res.status(500).send('Error fetching stats');
  }
});

// Admin - Create user (including admins)
app.post('/admin/users', 
  authenticate, 
  isAdmin,
  validate([
    body('name').notEmpty().trim(),
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 8 }),
    body('role').isIn(['user', 'owner', 'admin']),
    body('address').optional().trim()
  ]),
  async (req, res) => {
    const { name, email, address, password, role } = req.body;
    
    try {
      const existingUser = await pool.query("SELECT * FROM users WHERE email = $1", [email]);
      if (existingUser.rows.length > 0) {
        return res.status(400).json({ message: "User already exists" });
      }
      
      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      
      await pool.query(
        "INSERT INTO users (name, email, address, password, role) VALUES ($1, $2, $3, $4, $5)",
        [name, email, address, hashedPassword, role]
      );
      
      res.status(201).json({ message: "User created successfully" });
    } catch (err) {
      console.error('Error creating user:', err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

// Admin - Update user
app.put('/admin/users/:id', 
  authenticate, 
  isAdmin,
  validate([
    body('name').optional().trim(),
    body('email').optional().isEmail().normalizeEmail(),
    body('password').optional().isLength({ min: 8 }),
    body('role').optional().isIn(['user', 'owner', 'admin']),
    body('address').optional().trim()
  ]),
  async (req, res) => {
    const userId = req.params.id;
    const { name, email, address, password, role } = req.body;
    
    try {
      // Check if user exists
      const userResult = await pool.query('SELECT * FROM users WHERE id = $1', [userId]);
      if (userResult.rows.length === 0) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Build update query dynamically
      const updates = [];
      const params = [];
      let paramCount = 1;
      
      if (name) {
        updates.push(`name = $${paramCount++}`);
        params.push(name);
      }
      if (email) {
        updates.push(`email = $${paramCount++}`);
        params.push(email);
      }
      if (address) {
        updates.push(`address = $${paramCount++}`);
        params.push(address);
      }
      if (role) {
        updates.push(`role = $${paramCount++}`);
        params.push(role);
      }
      if (password) {
        const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
        updates.push(`password = $${paramCount++}`);
        params.push(hashedPassword);
      }
      
      if (updates.length === 0) {
        return res.status(400).json({ message: "No fields to update" });
      }
      
      params.push(userId);
      const query = `UPDATE users SET ${updates.join(', ')} WHERE id = $${paramCount}`;
      
      await pool.query(query, params);
      res.json({ message: "User updated successfully" });
    } catch (err) {
      console.error('Error updating user:', err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

// Admin - Delete user
app.delete('/admin/users/:id', authenticate, isAdmin, async (req, res) => {
  const userId = req.params.id;
  
  try {
    // Check if user exists
    const userResult = await pool.query('SELECT * FROM users WHERE id = $1', [userId]);
    if (userResult.rows.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }
    
    await pool.query('DELETE FROM users WHERE id = $1', [userId]);
    res.json({ message: "User deleted successfully" });
  } catch (err) {
    console.error('Error deleting user:', err);
    res.status(500).json({ message: "Server error" });
  }
});

// Admin - List users with pagination
app.get('/admin/users', authenticate, isAdmin, async (req, res) => {
  const { name, email, address, role, page = 1, limit = 10 } = req.query;
  const offset = (page - 1) * limit;
  
  try {
    let query = 'SELECT id, name, email, address, role FROM users WHERE 1=1';
    let countQuery = 'SELECT COUNT(*) FROM users WHERE 1=1';
    const params = [];
    const countParams = [];
    
    if (name) {
      params.push(`%${name}%`);
      countParams.push(`%${name}%`);
      query += ` AND name ILIKE $${params.length}`;
      countQuery += ` AND name ILIKE $${countParams.length}`;
    }
    if (email) {
      params.push(`%${email}%`);
      countParams.push(`%${email}%`);
      query += ` AND email ILIKE $${params.length}`;
      countQuery += ` AND email ILIKE $${countParams.length}`;
    }
    if (address) {
      params.push(`%${address}%`);
      countParams.push(`%${address}%`);
      query += ` AND address ILIKE $${params.length}`;
      countQuery += ` AND address ILIKE $${countParams.length}`;
    }
    if (role) {
      params.push(role);
      countParams.push(role);
      query += ` AND role = $${params.length}`;
      countQuery += ` AND role = $${countParams.length}`;
    }
    
    // Add pagination
    params.push(limit);
    params.push(offset);
    query += ` LIMIT $${params.length - 1} OFFSET $${params.length}`;
    
    const [result, countResult] = await Promise.all([
      pool.query(query, params),
      pool.query(countQuery, countParams)
    ]);
    
    res.json({
      users: result.rows,
      total: parseInt(countResult.rows[0].count),
      page: parseInt(page),
      limit: parseInt(limit)
    });
  } catch (err) {
    console.error('Error fetching users:', err);
    res.status(500).send('Error fetching users');
  }
});

// Admin - User detail
app.get('/admin/users/:id', authenticate, isAdmin, async (req, res) => {
  const userId = req.params.id;
  try {
    const userResult = await pool.query('SELECT id, name, email, address, role FROM users WHERE id = $1', [userId]);
    if (userResult.rows.length === 0) return res.status(404).send('User not found');
    
    const user = userResult.rows[0];
    
    if (user.role === 'owner') {
      const storeResult = await pool.query(
        `SELECT s.id, s.name, s.email, s.address, 
                COALESCE(ROUND(AVG(r.rating), 1), 0) AS avg_rating
         FROM stores s
         LEFT JOIN ratings r ON s.id = r.store_id
         WHERE s.owner_id = $1
         GROUP BY s.id`,
        [userId]
      );
      user.stores = storeResult.rows;
    }
    
    res.json(user);
  } catch (err) {
    console.error('Error fetching user details:', err);
    res.status(500).send('Error fetching user details');
  }
});

// Admin - Add store
app.post('/admin/stores', 
  authenticate, 
  isAdmin,
  validate([
    body('name').notEmpty().trim(),
    body('email').optional().isEmail().normalizeEmail(),
    body('address').notEmpty().trim(),
    body('owner_id').optional().isInt()
  ]),
  async (req, res) => {
    const { name, email, address, owner_id } = req.body;
    
    try {
      // Verify owner exists if provided
      if (owner_id) {
        const owner = await pool.query('SELECT * FROM users WHERE id = $1 AND role = $2', 
          [owner_id, 'owner']);
        if (owner.rows.length === 0) {
          return res.status(400).json({ message: "Owner not found or not an owner" });
        }
      }
      
      await pool.query(
        "INSERT INTO stores (name, email, address, owner_id) VALUES ($1, $2, $3, $4)",
        [name, email, address, owner_id || null]
      );
      res.status(201).json({ message: "Store added successfully" });
    } catch (err) {
      console.error('Error adding store:', err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

// Admin - Update store
app.put('/admin/stores/:id', 
  authenticate, 
  isAdmin,
  validate([
    body('name').optional().trim(),
    body('email').optional().isEmail().normalizeEmail(),
    body('address').optional().trim(),
    body('owner_id').optional().isInt()
  ]),
  async (req, res) => {
    const storeId = req.params.id;
    const { name, email, address, owner_id } = req.body;
    
    try {
      // Check if store exists
      const storeResult = await pool.query('SELECT * FROM stores WHERE id = $1', [storeId]);
      if (storeResult.rows.length === 0) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      // Verify owner exists if provided
      if (owner_id) {
        const owner = await pool.query('SELECT * FROM users WHERE id = $1 AND role = $2', 
          [owner_id, 'owner']);
        if (owner.rows.length === 0) {
          return res.status(400).json({ message: "Owner not found or not an owner" });
        }
      }
      
      // Build update query
      const updates = [];
      const params = [];
      let paramCount = 1;
      
      if (name) {
        updates.push(`name = $${paramCount++}`);
        params.push(name);
      }
      if (email) {
        updates.push(`email = $${paramCount++}`);
        params.push(email);
      }
      if (address) {
        updates.push(`address = $${paramCount++}`);
        params.push(address);
      }
      if (owner_id !== undefined) {
        updates.push(`owner_id = $${paramCount++}`);
        params.push(owner_id || null);
      }
      
      if (updates.length === 0) {
        return res.status(400).json({ message: "No fields to update" });
      }
      
      params.push(storeId);
      const query = `UPDATE stores SET ${updates.join(', ')} WHERE id = $${paramCount}`;
      
      await pool.query(query, params);
      res.json({ message: "Store updated successfully" });
    } catch (err) {
      console.error('Error updating store:', err);
      res.status(500).json({ message: "Server error" });
    }
  }
);

// Admin - Delete store
app.delete('/admin/stores/:id', authenticate, isAdmin, async (req, res) => {
  const storeId = req.params.id;
  
  try {
    // Check if store exists
    const storeResult = await pool.query('SELECT * FROM stores WHERE id = $1', [storeId]);
    if (storeResult.rows.length === 0) {
      return res.status(404).json({ message: "Store not found" });
    }
    
    await pool.query('DELETE FROM stores WHERE id = $1', [storeId]);
    res.json({ message: "Store deleted successfully" });
  } catch (err) {
    console.error('Error deleting store:', err);
    res.status(500).json({ message: "Server error" });
  }
});

// Admin - List stores with pagination
app.get('/admin/stores', authenticate, isAdmin, async (req, res) => {
  const { name, email, address, owner_id, page = 1, limit = 10 } = req.query;
  const offset = (page - 1) * limit;
  
  try {
    let query = `
      SELECT s.*, u.name as owner_name, AVG(r.rating)::numeric(2,1) as avg_rating
      FROM stores s
      LEFT JOIN users u ON s.owner_id = u.id
      LEFT JOIN ratings r ON s.id = r.store_id
      WHERE 1=1
    `;
    
    let countQuery = 'SELECT COUNT(*) FROM stores WHERE 1=1';
    const params = [];
    const countParams = [];
    
    if (name) {
      params.push(`%${name}%`);
      countParams.push(`%${name}%`);
      query += ` AND s.name ILIKE $${params.length}`;
      countQuery += ` AND name ILIKE $${countParams.length}`;
    }
    if (email) {
      params.push(`%${email}%`);
      countParams.push(`%${email}%`);
      query += ` AND s.email ILIKE $${params.length}`;
      countQuery += ` AND email ILIKE $${countParams.length}`;
    }
    if (address) {
      params.push(`%${address}%`);
      countParams.push(`%${address}%`);
      query += ` AND s.address ILIKE $${params.length}`;
      countQuery += ` AND address ILIKE $${countParams.length}`;
    }
    if (owner_id) {
      params.push(owner_id);
      countParams.push(owner_id);
      query += ` AND s.owner_id = $${params.length}`;
      countQuery += ` AND owner_id = $${countParams.length}`;
    }
    
    // Add grouping and pagination
    query += ' GROUP BY s.id, u.name';
    params.push(limit);
    params.push(offset);
    query += ` LIMIT $${params.length - 1} OFFSET $${params.length}`;
    
    const [result, countResult] = await Promise.all([
      pool.query(query, params),
      pool.query(countQuery, countParams)
    ]);
    
    res.json({
      stores: result.rows,
      total: parseInt(countResult.rows[0].count),
      page: parseInt(page),
      limit: parseInt(limit)
    });
  } catch (err) {
    console.error('Error fetching stores:', err);
    res.status(500).send('Error fetching stores');
  }
});

// User - Update password
app.put('/user/password', 
  authenticate,
  validate([
    body('newPassword').isLength({ min: 8 })
  ]),
  async (req, res) => {
    const { newPassword } = req.body;
    
    try {
      const hashedPassword = await bcrypt.hash(newPassword, SALT_ROUNDS);
      await pool.query('UPDATE users SET password = $1 WHERE id = $2', [hashedPassword, req.user.id]);
      res.json({ message: "Password updated successfully" });
    } catch (err) {
      console.error('Error updating password:', err);
      res.status(500).json({ message: "Error updating password" });
    }
  }
);

// Submit or update rating
app.post('/ratings', 
  authenticate, 
  isUser,
  validate([
    body('store_id').isInt(),
    body('rating').isInt({ min: 1, max: 5 })
  ]),
  async (req, res) => {
    const { store_id, rating } = req.body;
    
    try {
      // Check if store exists
      const store = await pool.query('SELECT * FROM stores WHERE id = $1', [store_id]);
      if (store.rows.length === 0) {
        return res.status(404).json({ message: "Store not found" });
      }
      
      // Check if rating already exists
      const existingRating = await pool.query(
        'SELECT * FROM ratings WHERE user_id = $1 AND store_id = $2',
        [req.user.id, store_id]
      );
      
      if (existingRating.rows.length > 0) {
        // Update existing rating
        await pool.query(
          'UPDATE ratings SET rating = $1 WHERE user_id = $2 AND store_id = $3',
          [rating, req.user.id, store_id]
        );
        res.json({ message: "Rating updated successfully" });
      } else {
        // Create new rating
        await pool.query(
          'INSERT INTO ratings (user_id, store_id, rating) VALUES ($1, $2, $3)',
          [req.user.id, store_id, rating]
        );
        res.status(201).json({ message: "Rating submitted successfully" });
      }
    } catch (err) {
      console.error('Error submitting rating:', err);
      res.status(500).json({ message: "Error submitting rating" });
    }
  }
);

// Get user's rating for a store
app.get('/user/ratings/:store_id', authenticate, isUser, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT rating FROM ratings WHERE user_id = $1 AND store_id = $2',
      [req.user.id, req.params.store_id]
    );
    
    res.json({ 
      rating: result.rows.length > 0 ? result.rows[0].rating : null 
    });
  } catch (err) {
    res.status(500).json({ message: "Error fetching rating" });
  }
});

// Public store listing (for all users)
app.get('/stores', async (req, res) => {
    const { name, address, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;
    
    try {
      let query = `
        SELECT s.*, u.name as owner_name, AVG(r.rating)::numeric(2,1) as avg_rating
        FROM stores s
        LEFT JOIN users u ON s.owner_id = u.id
        LEFT JOIN ratings r ON s.id = r.store_id
        WHERE 1=1
      `;
      
      let countQuery = 'SELECT COUNT(*) FROM stores WHERE 1=1';
      const params = [];
      const countParams = [];
      
      if (name) {
        params.push(`%${name}%`);
        countParams.push(`%${name}%`);
        query += ` AND s.name ILIKE $${params.length}`;
        countQuery += ` AND name ILIKE $${countParams.length}`;
      }
      if (address) {
        params.push(`%${address}%`);
        countParams.push(`%${address}%`);
        query += ` AND s.address ILIKE $${params.length}`;
        countQuery += ` AND address ILIKE $${countParams.length}`;
      }
      
      // Add grouping and pagination
      query += ' GROUP BY s.id, u.name';
      params.push(limit);
      params.push(offset);
      query += ` LIMIT $${params.length - 1} OFFSET $${params.length}`;
      
      const [result, countResult] = await Promise.all([
        pool.query(query, params),
        pool.query(countQuery, countParams)
      ]);
      
      res.json({
        stores: result.rows,
        total: parseInt(countResult.rows[0].count),
        page: parseInt(page),
        limit: parseInt(limit)
      });
    } catch (err) {
      console.error('Error fetching stores:', err);
      res.status(500).send('Error fetching stores');
    }
  });

// Owner - View ratings
// Owner - View ratings
app.get('/owner/ratings', authenticate, isOwner, async (req, res) => {
    try {
      // Get all stores owned by this owner
      const storeResult = await pool.query('SELECT id FROM stores WHERE owner_id = $1', [req.user.id]);
      if (storeResult.rows.length === 0) {
        return res.status(404).json({ message: "No stores found for this owner" });
      }
      
      const storeIds = storeResult.rows.map(s => s.id);
      
      const [ratingsResult, avgRatingsResult] = await Promise.all([
        pool.query(
          `SELECT r.rating, r.store_id, u.name AS user_name, u.email AS user_email, s.name AS store_name
           FROM ratings r
           JOIN users u ON r.user_id = u.id
           JOIN stores s ON r.store_id = s.id
           WHERE r.store_id = ANY($1)`,
          [storeIds]
        ),
        pool.query(
          `SELECT store_id, ROUND(AVG(rating), 1) AS avg_rating 
           FROM ratings 
           WHERE store_id = ANY($1)
           GROUP BY store_id`,
          [storeIds]
        )
      ]);
      
      // Format response with average ratings per store
      const avgRatings = {};
      avgRatingsResult.rows.forEach(row => {
        avgRatings[row.store_id] = row.avg_rating;
      });
      
      res.json({
        ratings: ratingsResult.rows,
        average_ratings: avgRatings
      });
    } catch (err) {
      console.error('Error fetching ratings:', err);
      res.status(500).json({ message: "Error fetching ratings" });
    }
  });

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Something went wrong!" });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});