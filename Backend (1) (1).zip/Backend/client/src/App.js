import React, { useState, useEffect } from 'react';
import axios from 'axios';

const styles = {
  container: { 
    padding: 20, 
    fontFamily: 'Arial', 
    maxWidth: 800, 
    margin: 'auto',
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    minHeight: '100vh'
  },
  form: { 
    display: 'flex', 
    flexDirection: 'column', 
    gap: 10, 
    marginTop: 20,
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 8
  },
  statsContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: 20,
    flexWrap: 'wrap',
    gap: 10
  },
  statCard: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8,
    minWidth: 150,
    textAlign: 'center',
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
    flex: 1
  },
  filterContainer: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
    gap: 10,
    marginBottom: 20,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8
  },
  searchContainer: {
    margin: '20px 0',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8
  },
  card: { 
    border: '1px solid #ddd', 
    padding: 15, 
    borderRadius: 8, 
    marginTop: 10, 
    backgroundColor: 'white',
    cursor: 'pointer',
    transition: 'transform 0.2s',
    ':hover': {
      transform: 'scale(1.02)',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
    }
  },
  userList: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
    gap: 15
  },
  detailsPanel: {
    marginTop: 20,
    padding: 20,
    backgroundColor: 'white',
    borderRadius: 8,
    borderLeft: '4px solid #4CAF50'
  },
  storeList: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: 20
  },
  storeCard: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8,
    boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
  },
  storeRatingCard: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderLeft: '3px solid #2196F3'
  },
  ratingSelect: {
    marginLeft: 10,
    padding: 5,
    borderRadius: 4
  },
  ratingsList: {
    marginTop: 15,
    display: 'flex',
    flexDirection: 'column',
    gap: 10
  },
  ratingCard: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 8,
    borderLeft: '3px solid #FFC107'
  },
  loading: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    color: 'white',
    fontSize: '1.5rem',
    zIndex: 1000
  },
  section: {
    margin: '20px 0',
    padding: '15px',
    backgroundColor: 'white',
    borderRadius: '8px'
  },
  actionButtons: {
    display: 'flex',
    gap: '10px',
    marginTop: '10px'
  },
  pagination: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    gap: '20px',
    margin: '20px 0'
  },
  error: {
    color: 'red',
    margin: '10px 0'
  },
  adminLink: {
    marginTop: '10px',
    fontSize: '0.9rem',
    textAlign: 'center'
  }
};

function App() {
  const [view, setView] = useState('login');
  const [form, setForm] = useState({ 
    name: '', 
    email: '', 
    address: '', 
    password: '', 
    role: 'user',
    adminKey: '' 
  });
  const [user, setUser] = useState(null);
  const [token, setToken] = useState('');
  const [stores, setStores] = useState([]);
  const [dashboardStats, setDashboardStats] = useState(null);
  const [filter, setFilter] = useState({ name: '', email: '', address: '', role: '' });
  const [users, setUsers] = useState({ data: [], total: 0, page: 1, limit: 10 });
  const [ownerRatings, setOwnerRatings] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [userDetails, setUserDetails] = useState(null);
  const [newPassword, setNewPassword] = useState('');
  const [storeSearch, setStoreSearch] = useState({ name: '', address: '' });
  const [userRatings, setUserRatings] = useState({});
  const [loading, setLoading] = useState(false);
  const [storePagination, setStorePagination] = useState({ page: 1, limit: 10, total: 0 });
  const [error, setError] = useState('');

  const backend = 'http://localhost:3000';

  const axiosAuth = axios.create({
    baseURL: backend,
    headers: { Authorization: `Bearer ${token}` }
  });

  axiosAuth.interceptors.response.use(
    response => response,
    error => {
      if (error.response?.status === 401) {
        setError('Session expired. Please login again.');
        setUser(null);
        setToken('');
        setView('login');
      }
      return Promise.reject(error);
    }
  );

  const handleInputChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleFilterChange = e => {
    setFilter({ ...filter, [e.target.name]: e.target.value });
    setError('');
  };

  const handleStoreSearchChange = e => {
    setStoreSearch({ ...storeSearch, [e.target.name]: e.target.value });
    setError('');
  };

  const registerAdmin = async e => {
    e.preventDefault();
    setError('');
    try {
      const response = await axios.post(`${backend}/register-admin`, {
        name: form.name,
        email: form.email,
        address: form.address,
        password: form.password,
        admin_key: form.adminKey
      });
      
      if (response.data.message) {
        alert('Admin registration successful! You can now log in.');
        setForm({ name: '', email: '', address: '', password: '', role: 'user', adminKey: '' });
        setView('login');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Admin registration failed. Please try again.');
      console.error('Admin registration error:', err);
    }
  };

  const register = async e => {
    e.preventDefault();
    setError('');
    try {
      const registrationData = { ...form };
      delete registrationData.adminKey;
      if (registrationData.role === 'admin') {
        registrationData.role = 'user';
      }

      const response = await axios.post(`${backend}/register`, registrationData);
      if (response.data.message) {
        alert('Registration successful! You can now log in.');
        setForm({ name: '', email: '', address: '', password: '', role: 'user', adminKey: '' });
        setView('login');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Please try again.');
      console.error('Registration error:', err);
    }
  };

  const login = async e => {
    e.preventDefault();
    setError('');
    try {
      const res = await axios.post(`${backend}/login`, { 
        email: form.email, 
        password: form.password 
      });
      
      if (res.data.token && res.data.user) {
        setUser(res.data.user);
        setToken(res.data.token);
        setView('dashboard');
        localStorage.setItem('authToken', res.data.token);
      } else {
        setError('Invalid login response from server');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please check your credentials.');
      console.error('Login error:', err);
    }
  };

  useEffect(() => {
    const savedToken = localStorage.getItem('authToken');
    if (savedToken) {
      setToken(savedToken);
    }
  }, []);

  const fetchStores = async (page = 1) => {
    setLoading(true);
    setError('');
    try {
      const query = new URLSearchParams({
        ...storeSearch,
        page,
        limit: storePagination.limit
      }).toString();
      
      const res = await axios.get(`${backend}/stores?${query}`);
      if (res.data?.stores) {
        setStores(res.data.stores);
        setStorePagination({
          page: res.data.page,
          limit: res.data.limit,
          total: res.data.total
        });
        
        if (user?.role === 'user') {
          const ratings = {};
          for (const store of res.data.stores) {
            try {
              const ratingRes = await axiosAuth.get(`/user/ratings/${store.id}`);
              ratings[store.id] = ratingRes.data.rating;
            } catch {
              ratings[store.id] = null;
            }
          }
          setUserRatings(ratings);
        }
      } else {
        setError('Invalid stores data received');
      }
    } catch (err) {
      setError('Failed to load stores. Please try again.');
      console.error('Fetch stores error:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchDashboardStats = async () => {
    setError('');
    try {
      const res = await axiosAuth.get('/admin/stats');
      if (res.data) {
        setDashboardStats(res.data);
      } else {
        setError('Invalid stats data received');
      }
    } catch (err) {
      setError('Failed to fetch dashboard stats');
      console.error('Fetch stats error:', err);
    }
  };

  const fetchUsers = async (page = 1) => {
    setLoading(true);
    setError('');
    try {
      const query = new URLSearchParams({
        ...filter,
        page,
        limit: users.limit
      }).toString();
      
      const res = await axiosAuth.get(`/admin/users?${query}`);
      if (res.data?.users) {
        setUsers({
          data: res.data.users,
          total: res.data.total,
          page: res.data.page,
          limit: res.data.limit
        });
      } else {
        setError('Invalid users data received');
      }
    } catch (err) {
      setError('Failed to fetch users');
      console.error('Fetch users error:', err);
    } finally {
      setLoading(false);
    }
  };

  const createUser = async (userData) => {
    setError('');
    try {
      const res = await axiosAuth.post('/admin/users', userData);
      if (res.data.message) {
        alert('User created successfully');
        fetchUsers();
      } else {
        setError('Failed to create user');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create user');
      console.error('Create user error:', err);
    }
  };

  const updateUser = async (userId, userData) => {
    setError('');
    try {
      const res = await axiosAuth.put(`/admin/users/${userId}`, userData);
      if (res.data.message) {
        alert('User updated successfully');
        fetchUsers();
        if (userId === selectedUserId) {
          fetchUserDetails(userId);
        }
      } else {
        setError('Failed to update user');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update user');
      console.error('Update user error:', err);
    }
  };

  const deleteUser = async (userId) => {
    if (!window.confirm('Are you sure you want to delete this user?')) return;
    setError('');
    try {
      const res = await axiosAuth.delete(`/admin/users/${userId}`);
      if (res.data.message) {
        alert('User deleted successfully');
        fetchUsers();
        if (userId === selectedUserId) {
          setSelectedUserId(null);
          setUserDetails(null);
        }
      } else {
        setError('Failed to delete user');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete user');
      console.error('Delete user error:', err);
    }
  };

  const createStore = async (storeData) => {
    setError('');
    try {
      const res = await axiosAuth.post('/admin/stores', storeData);
      if (res.data.message) {
        alert('Store created successfully');
        fetchStores();
      } else {
        setError('Failed to create store');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create store');
      console.error('Create store error:', err);
    }
  };

  const updateStore = async (storeId, storeData) => {
    setError('');
    try {
      const res = await axiosAuth.put(`/admin/stores/${storeId}`, storeData);
      if (res.data.message) {
        alert('Store updated successfully');
        fetchStores();
      } else {
        setError('Failed to update store');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update store');
      console.error('Update store error:', err);
    }
  };

  const deleteStore = async (storeId) => {
    if (!window.confirm('Are you sure you want to delete this store?')) return;
    setError('');
    try {
      const res = await axiosAuth.delete(`/admin/stores/${storeId}`);
      if (res.data.message) {
        alert('Store deleted successfully');
        fetchStores();
      } else {
        setError('Failed to delete store');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to delete store');
      console.error('Delete store error:', err);
    }
  };

  const fetchUserDetails = async (userId) => {
    setError('');
    try {
      const res = await axiosAuth.get(`/admin/users/${userId}`);
      if (res.data) {
        setUserDetails(res.data);
      } else {
        setError('Invalid user details received');
      }
    } catch (err) {
      setError('Failed to fetch user details');
      console.error('Fetch user details error:', err);
    }
  };

  const fetchOwnerRatings = async () => {
    setError('');
    try {
      const res = await axiosAuth.get('/owner/ratings');
      if (res.data) {
        setOwnerRatings(res.data);
      } else {
        setError('Invalid ratings data received');
      }
    } catch (err) {
      if (err.response?.status === 404) {
        setError('No ratings found for your stores');
      } else {
        setError('Failed to fetch ratings');
      }
      console.error('Fetch ratings error:', err);
    }
  };

  const updatePassword = async () => {
    setError('');
    try {
      const res = await axiosAuth.put('/user/password', { newPassword });
      if (res.data.message) {
        alert('Password updated successfully');
        setNewPassword('');
      } else {
        setError('Failed to update password');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update password');
      console.error('Update password error:', err);
    }
  };

  const submitRating = async (storeId, rating) => {
    setError('');
    try {
      const res = await axiosAuth.post('/ratings', { store_id: storeId, rating });
      if (res.data.message) {
        alert('Rating submitted successfully');
        fetchStores();
      } else {
        setError('Failed to submit rating');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit rating');
      console.error('Submit rating error:', err);
    }
  };

  useEffect(() => {
    if (view === 'dashboard' && token) {
      fetchStores();
      if (user?.role === 'admin') {
        fetchDashboardStats();
        fetchUsers();
      }
      if (user?.role === 'owner') fetchOwnerRatings();
    }
  }, [view, token, user]);

  if (view === 'register') {
    return (
      <div style={styles.container}>
        <h2>Register</h2>
        {error && <div style={styles.error}>{error}</div>}
        <form onSubmit={register} style={styles.form}>
          <input name="name" placeholder="Name" onChange={handleInputChange} required />
          <input name="email" type="email" placeholder="Email" onChange={handleInputChange} required />
          <input name="address" placeholder="Address" onChange={handleInputChange} />
          <input name="password" type="password" placeholder="Password" onChange={handleInputChange} required />
          <select name="role" onChange={handleInputChange} value={form.role}>
            <option value="user">User</option>
            <option value="owner">Owner</option>
          </select>
          <button type="submit">Register</button>
        </form>
        <p>Already have an account? <button onClick={() => setView('login')}>Login</button></p>
      </div>
    );
  }
  
  if (view === 'login') {
    return (
      <div style={styles.container}>
        <h2>Login</h2>
        {error && <div style={styles.error}>{error}</div>}
        <form onSubmit={login} style={styles.form}>
          <input name="email" type="email" placeholder="Email" onChange={handleInputChange} required />
          <input name="password" type="password" placeholder="Password" onChange={handleInputChange} required />
          <button type="submit">Login</button>
        </form>
        <p>Don't have an account? <button onClick={() => setView('register')}>Register</button></p>
        <div style={styles.adminLink}>
          <button onClick={() => setView('register-admin')}>Register as Admin</button>
        </div>
      </div>
    );
  }

  if (view === 'register-admin') {
    return (
      <div style={styles.container}>
        <h2>Admin Registration</h2>
        {error && <div style={styles.error}>{error}</div>}
        <form onSubmit={registerAdmin} style={styles.form}>
          <input name="name" placeholder="Name" onChange={handleInputChange} required />
          <input name="email" type="email" placeholder="Email" onChange={handleInputChange} required />
          <input name="address" placeholder="Address" onChange={handleInputChange} />
          <input name="password" type="password" placeholder="Password" onChange={handleInputChange} required />
          <input 
            name="adminKey" 
            type="password" 
            placeholder="Admin Secret Key" 
            onChange={handleInputChange} 
            required 
          />
          <button type="submit">Register Admin</button>
        </form>
        <p>Already have an account? <button onClick={() => setView('login')}>Login</button></p>
      </div>
    );
  }

  if (view === 'dashboard') {
    if (!user) {
      return (
        <div style={styles.container}>
          <h2>Session Expired</h2>
          <p>Please log in again</p>
          <button onClick={() => setView('login')}>Go to Login</button>
        </div>
      );
    }

    return (
      <div style={styles.container}>
        <h2>Welcome, {user.name} ({user.role})</h2>
        <button onClick={() => { 
          setUser(null); 
          setToken(''); 
          localStorage.removeItem('authToken');
          setView('login'); 
        }}>Logout</button>

        {loading && <div style={styles.loading}>Loading...</div>}
        {error && <div style={styles.error}>{error}</div>}

        {user.role === 'admin' && (
          <AdminDashboard 
            dashboardStats={dashboardStats}
            newPassword={newPassword}
            setNewPassword={setNewPassword}
            updatePassword={updatePassword}
            createUser={createUser}
            createStore={createStore}
            filter={filter}
            handleFilterChange={handleFilterChange}
            fetchUsers={fetchUsers}
            users={users}
            deleteUser={deleteUser}
            selectedUserId={selectedUserId}
            setSelectedUserId={setSelectedUserId}
            fetchUserDetails={fetchUserDetails}
            userDetails={userDetails}
            updateUser={updateUser}
            stores={stores}
            deleteStore={deleteStore}
            storePagination={storePagination}
            fetchStores={fetchStores}
          />
        )}

        {user.role === 'owner' && ownerRatings && (
          <OwnerDashboard 
            newPassword={newPassword}
            setNewPassword={setNewPassword}
            updatePassword={updatePassword}
            ownerRatings={ownerRatings}
          />
        )}

        {user.role === 'user' && (
          <UserDashboard 
            newPassword={newPassword}
            setNewPassword={setNewPassword}
            updatePassword={updatePassword}
            storeSearch={storeSearch}
            handleStoreSearchChange={handleStoreSearchChange}
            fetchStores={fetchStores}
            stores={stores}
            userRatings={userRatings}
            submitRating={submitRating}
          />
        )}
      </div>
    );
  }

  return (
    <div style={styles.container}>
      <h2>Loading Application...</h2>
    </div>
  );
}

function AdminDashboard({
  dashboardStats,
  newPassword,
  setNewPassword,
  updatePassword,
  createUser,
  createStore,
  filter,
  handleFilterChange,
  fetchUsers,
  users,
  deleteUser,
  selectedUserId,
  setSelectedUserId,
  fetchUserDetails,
  userDetails,
  updateUser,
  stores,
  deleteStore,
  storePagination,
  fetchStores
}) {
  return (
    <div>
      <h3>Admin Dashboard</h3>

      {dashboardStats && (
        <div style={styles.statsContainer}>
          <div style={styles.statCard}>
            <h4>Total Users</h4>
            <p>{dashboardStats.totalUsers}</p>
          </div>
          <div style={styles.statCard}>
            <h4>Total Stores</h4>
            <p>{dashboardStats.totalStores}</p>
          </div>
          <div style={styles.statCard}>
            <h4>Total Ratings</h4>
            <p>{dashboardStats.totalRatings}</p>
          </div>
        </div>
      )}

      <div style={{ margin: '20px 0' }}>
        <h4>Password Update</h4>
        <input 
          type="password" 
          placeholder="New Password" 
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        <button onClick={updatePassword}>Update Password</button>
      </div>

      <div style={styles.section}>
        <h4>Create New User</h4>
        <form onSubmit={(e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          createUser({
            name: formData.get('name'),
            email: formData.get('email'),
            address: formData.get('address'),
            password: formData.get('password'),
            role: formData.get('role')
          });
          e.target.reset();
        }} style={styles.form}>
          <input name="name" placeholder="Name" required />
          <input name="email" type="email" placeholder="Email" required />
          <input name="address" placeholder="Address" />
          <input name="password" type="password" placeholder="Password" required />
          <select name="role" required>
            <option value="user">User</option>
            <option value="owner">Owner</option>
            <option value="admin">Admin</option>
          </select>
          <button type="submit">Create User</button>
        </form>
      </div>

      <div style={styles.section}>
        <h4>Create New Store</h4>
        <form onSubmit={(e) => {
          e.preventDefault();
          const formData = new FormData(e.target);
          createStore({
            name: formData.get('name'),
            email: formData.get('email'),
            address: formData.get('address'),
            owner_id: formData.get('owner_id') || null
          });
          e.target.reset();
        }} style={styles.form}>
          <input name="name" placeholder="Store Name" required />
          <input name="email" type="email" placeholder="Store Email" />
          <input name="address" placeholder="Store Address" required />
          <input name="owner_id" type="number" placeholder="Owner ID (optional)" />
          <button type="submit">Create Store</button>
        </form>
      </div>

      <h4>User Filters</h4>
      <div style={styles.filterContainer}>
        <input placeholder="Name" name="name" onChange={handleFilterChange} />
        <input placeholder="Email" name="email" onChange={handleFilterChange} />
        <input placeholder="Address" name="address" onChange={handleFilterChange} />
        <select name="role" onChange={handleFilterChange} value={filter.role}>
          <option value="">All Roles</option>
          <option value="user">User</option>
          <option value="owner">Owner</option>
          <option value="admin">Admin</option>
        </select>
        <button onClick={() => fetchUsers(1)}>Search</button>
      </div>

      <h4>User List</h4>
      <div style={styles.userList}>
        {users.data.map(u => (
          <div key={u.id} style={styles.card}>
            <strong>{u.name}</strong> ({u.role})<br />
            {u.email}<br />
            {u.address}
            <div style={styles.actionButtons}>
              <button onClick={() => {
                setSelectedUserId(u.id);
                fetchUserDetails(u.id);
              }}>View</button>
              <button onClick={() => deleteUser(u.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      <div style={styles.pagination}>
        <button 
          disabled={users.page <= 1}
          onClick={() => fetchUsers(users.page - 1)}
        >
          Previous
        </button>
        <span>Page {users.page} of {Math.ceil(users.total / users.limit)}</span>
        <button 
          disabled={users.page >= Math.ceil(users.total / users.limit)}
          onClick={() => fetchUsers(users.page + 1)}
        >
          Next
        </button>
      </div>

      {userDetails && (
        <div style={styles.detailsPanel}>
          <h4>User Details</h4>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            updateUser(userDetails.id, {
              name: formData.get('name') || userDetails.name,
              email: formData.get('email') || userDetails.email,
              address: formData.get('address') || userDetails.address,
              role: formData.get('role') || userDetails.role,
              password: formData.get('password') || undefined
            });
          }}>
            <label>Name:</label>
            <input name="name" defaultValue={userDetails.name} />
            
            <label>Email:</label>
            <input name="email" type="email" defaultValue={userDetails.email} />
            
            <label>Address:</label>
            <input name="address" defaultValue={userDetails.address} />
            
            <label>Role:</label>
            <select name="role" defaultValue={userDetails.role}>
              <option value="user">User</option>
              <option value="owner">Owner</option>
              <option value="admin">Admin</option>
            </select>
            
            <label>New Password (leave blank to keep current):</label>
            <input name="password" type="password" placeholder="New Password" />
            
            <button type="submit">Update User</button>
          </form>
          
          {userDetails.role === 'owner' && userDetails.stores && (
            <div>
              <h5>Owned Stores</h5>
              {userDetails.stores.length > 0 ? (
                userDetails.stores.map(store => (
                  <div key={store.id} style={styles.storeCard}>
                    <strong>{store.name}</strong><br />
                    {store.address}<br />
                    ⭐ Average Rating: {store.avg_rating}
                  </div>
                ))
              ) : (
                <p>No stores owned</p>
              )}
            </div>
          )}
        </div>
      )}

      <h4>Store List</h4>
      <div style={styles.storeList}>
        {stores.map(store => (
          <div key={store.id} style={styles.storeCard}>
            <strong>{store.name}</strong><br />
            📍 {store.address}<br />
            ✉️ {store.email}<br />
            {store.owner_name && `👤 Owner: ${store.owner_name}`}
            <div style={styles.actionButtons}>
              <button onClick={() => {
                // Show edit form or modal for the store
              }}>Edit</button>
              <button onClick={() => deleteStore(store.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
      <div style={styles.pagination}>
        <button 
          disabled={storePagination.page <= 1}
          onClick={() => fetchStores(storePagination.page - 1)}
        >
          Previous
        </button>
        <span>Page {storePagination.page} of {Math.ceil(storePagination.total / storePagination.limit)}</span>
        <button 
          disabled={storePagination.page >= Math.ceil(storePagination.total / storePagination.limit)}
          onClick={() => fetchStores(storePagination.page + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
}

function OwnerDashboard({
  newPassword,
  setNewPassword,
  updatePassword,
  ownerRatings
}) {
  return (
    <div>
      <h3>Store Owner Dashboard</h3>
      
      <div style={{ margin: '20px 0' }}>
        <h4>Password Update</h4>
        <input 
          type="password" 
          placeholder="New Password" 
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        <button onClick={updatePassword}>Update Password</button>
      </div>

      <h4>Store Ratings</h4>
      {Object.entries(ownerRatings.average_ratings || {}).map(([storeId, avgRating]) => (
        <div key={storeId} style={styles.storeRatingCard}>
          <h5>Store ID: {storeId}</h5>
          <p><strong>Average Rating:</strong> {avgRating || 'No ratings yet'}</p>
        </div>
      ))}
      
      <div style={styles.ratingsList}>
        {ownerRatings.ratings.length > 0 ? (
          ownerRatings.ratings.map((rating, idx) => (
            <div key={idx} style={styles.ratingCard}>
              <strong>{rating.user_name}</strong> ({rating.user_email})<br />
              Store: {rating.store_name}<br />
              Rating: {rating.rating} ⭐
            </div>
          ))
        ) : (
          <p>No ratings received yet</p>
        )}
      </div>
    </div>
  );
}

function UserDashboard({
  newPassword,
  setNewPassword,
  updatePassword,
  storeSearch,
  handleStoreSearchChange,
  fetchStores,
  stores,
  userRatings,
  submitRating
}) {
  return (
    <div>
      <h3>Stores</h3>
      
      <div style={{ margin: '20px 0' }}>
        <h4>Password Update</h4>
        <input 
          type="password" 
          placeholder="New Password" 
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        <button onClick={updatePassword}>Update Password</button>
      </div>

      <div style={styles.searchContainer}>
        <h4>Search Stores</h4>
        <input placeholder="Store Name" name="name" onChange={handleStoreSearchChange} />
        <input placeholder="Address" name="address" onChange={handleStoreSearchChange} />
        <button onClick={() => fetchStores(1)}>Search</button>
      </div>

      <div style={styles.storeList}>
        {stores.map(store => (
          <div key={store.id} style={styles.storeCard}>
            <strong>{store.name}</strong><br />
            📍 {store.address}<br />
            ✉️ {store.email}<br />
            ⭐ Average Rating: {store.avg_rating || 'No ratings yet'}<br />
            {userRatings[store.id] && (
              <p>Your Rating: {userRatings[store.id]} ⭐</p>
            )}
            <label>Rate this store:</label>
            <select 
              onChange={e => submitRating(store.id, e.target.value)} 
              defaultValue={userRatings[store.id] || ""}
              style={styles.ratingSelect}
            >
              <option value="" disabled>Choose rating</option>
              {[1, 2, 3, 4, 5].map(n => (
                <option key={n} value={n}>{n} ⭐</option>
              ))}
            </select>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;