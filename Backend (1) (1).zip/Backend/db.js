// db.js
const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'ratings_platform',
  password: '0954',
  port: 5432, // default port
});

module.exports = pool;
